import React from 'react';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';

import CustomCharts from './CustomCharts';

const App = () => {
  return (
    <div> 
      <h1>VAISNAVE ASSIGNMENT 1</h1> 

    <Card sx={{ minWidth: 275 }}>
      <CardContent>
        <Typography sx={{ fontSize: 14 }} color="text.secondary" gutterBottom>
          Charts Illustration
        </Typography>
        <CustomCharts/>
      </CardContent>
      <CardActions>
        <Button size="small">Chart View</Button>
      </CardActions>
    </Card>
    </div>
  );
}

export default App;